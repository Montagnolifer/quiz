// src/quizzes/dto/update-quiz-progress.dto.ts
export class UpdateQuizProgressDto {
    progress_id: string
    result_node_id: string
  }
  