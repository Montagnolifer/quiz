import { redirect } from "next/navigation"
import { FileText } from "lucide-react"
import { DynamicBanner } from "@/components/dashboard/dynamic-banner"
import { QuickAccessCard } from "@/components/dashboard/quick-access-card"
import { getLocalUser } from "@/lib/auth"

export default async function DashboardPage() {
  // Check if the user is authenticated using our local auth system
  const user = getLocalUser()

  if (!user) {
    redirect("/login")
  }

  // In a real app, we would fetch this data from the database
  // For now, we'll use a placeholder value
  const quizCount = 5 // Placeholder value

  return (
    <div className="space-y-8">
      {/* Dynamic Banner */}
      <DynamicBanner />

      {/* Quick Access Section */}
      <div>
        <h2 className="text-2xl font-bold tracking-tight mb-4">Quick Access</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <QuickAccessCard
            title="My Quizzes"
            description="View and manage all your created quizzes"
            icon={FileText}
            href="/dashboard/quizzes"
            stats={{
              value: quizCount,
              label: "Total Quizzes",
            }}
            className="md:col-span-1"
          />
        </div>
      </div>
    </div>
  )
}
