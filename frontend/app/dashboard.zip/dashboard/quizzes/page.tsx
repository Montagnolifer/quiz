import { Suspense } from "react"
import QuizList from "@/components/dashboard/quiz-list"

export const metadata = {
  title: "Quizzes | Quiz Builder",
  description: "Manage your quizzes",
}

export default function QuizzesPage() {
  return (
    <div className="container py-6">
      <Suspense fallback={<div className="text-center py-8">Loading quizzes...</div>}>
        <QuizList />
      </Suspense>
    </div>
  )
}
